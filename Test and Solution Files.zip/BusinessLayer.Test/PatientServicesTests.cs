﻿using NUnit.Framework;
using RestApi.BusinessLayer;
using RestApi.Models;
using RestApi.Models.Generic_Repository;
using RestApi.Models.Unit_of_Work;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestHelper;
using Moq;

namespace BusinessLayer.Test
{
    public class PatientServicesTests
    {
        #region Variables
        private IPatientServices _patientService;
        private IUnitofWork _unitOfWork;
        private List<Patient> _patients;
        private PatientRepository _patientRepository;
        private PatientContext _dbpatientContext;
        #endregion

        [TestFixtureSetUp]
        public void Setup()
        {
            _patients = SetUpPatients();
        }

        private static List<Patient> SetUpPatients()
        {
            var patientId = new int();
            var patients = DataInitializer.GetAllPatients();
            foreach (Patient pat in patients)
                pat.PatientId = ++patientId;
            return patients;
        }

        /// <summary>
        /// Service should return Episode Details if correct Patient id is supplied
        /// </summary>
        [Test]
        public void GetEpisodeInfoByRightIdTest()
        {
            var patientEpisodeInfo = _patientService.GetEpisodeInfoByPatientId(2);
            if (patientEpisodeInfo != null)
            {
                //Mapper.CreateMap<ProductEntity, Product>();
                //var productModel = Mapper.Map<ProductEntity, Product>(patientEpisodeInfo);
                Assert.AreEqual(patientEpisodeInfo,_patients.Find(a => a.FirstName.Contains("Millicent")));
            }
        }

        [Test]
        public void GetPatientByWrongIdTest()
        {
            var patient = _patientService.GetEpisodeInfoByPatientId(0);
            Assert.Null(patient);
        }

        [TestFixtureTearDown]
        public void DisposeAllObjects()
        {
            _patients = null;
        }

    }
}
