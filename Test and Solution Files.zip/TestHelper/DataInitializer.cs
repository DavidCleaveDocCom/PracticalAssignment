﻿using RestApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestHelper
{
    public class DataInitializer
    {
        public static List<Patient> GetAllPatients()
        {
            var patients = new List<Patient>
            {
                new Patient
                        {
                            DateOfBirth = new DateTime(1972, 10, 27),
                            FirstName = "Millicent",
                            LastName = "Hammond",
                            NhsNumber = "1111111111"
                        },
                    new Patient
                        {
                            DateOfBirth = new DateTime(1987, 2, 14),
                            FirstName = "Bobby",
                            LastName = "Atkins",
                            NhsNumber = "2222222222"
                        },
                    new Patient
                        {
                            DateOfBirth = new DateTime(1991, 12, 4),
                            FirstName = "Xanthe",
                            LastName = "Camembert",
                            NhsNumber = "3333333333"
                        }

            };
            return patients;
        }
    }
}
